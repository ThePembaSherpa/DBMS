<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Chileense RUT nummer",
    "DESC" => "Genereert een sleur / RUN Chileense Nationale Identification Number ."
);

$L["different_formats"] = "verschillende formaten";
$L["incomplete_fields"] = "Het type Rut gegevens dient te beschikken over het voorbeeld veld geselecteerd. Corrigeer de volgende rijen :";
$L["rut_default"] = "Standaard";
$L["only_number"] = "Slechts nummer";
$L["only_digit"] = "Alleen verificatie cijferige";

$L["thousands_separator"] = "duizenden separator";
$L["digit_uppercase"] = "hoofdletters cijferige";
$L["remove_dash"] = "uitsluiten dash";
