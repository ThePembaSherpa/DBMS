<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PAN",
    "DESC" => "Dieser Datentyp generiert zufällige, gültige Kreditkartennummern nach dem Format, das Sie angeben."
);

$L["pan_incomplete_fields"] = "Mindestens ein Kartenmarke gewählt werden. Bitte korrigieren Sie die folgenden Zeilen:";
$L["separator_help"] = "Die Zeichen, die Sie hier eingeben, wird verwendet, um die Räume in der Formatfeld Kreditkarte unten ersetzen. Um mehr als eine Trenn einzugeben, trennen Sie diese mit einer Pipe (|) Zeichen.";
$L["format_incomplete_fields"] = "Für PAN Feld CC Zahlenformate, Eingangs <b>X</b> und für Abscheider Eingangs <b>Räume</b> nach der Kartenlänge. Bitte korrigieren Sie die folgenden Zeilen:";
$L["pan_help_intro"] = "Es ist derzeit in der Lage ist Nummern für die folgenden Marken:";
$L["mastercard"] = "Mastercard";
$L["visa_electron"] = "Visa Electron";
$L["visa"] = "Visa";
$L["americanexpress"] = "American Express";
$L["discover"] = "Discover";
$L["american_diners"] = "American Diner's";
$L["carte_blanche"] = "Carte Blanche";
$L["diners_club_international"] = "Diner's Club International";
$L["enroute"] = "enRoute";
$L["jcb"] = "JCB";
$L["maestro"] = "Maestro";
$L["solo"] = "Solo";
$L["switch"] = "Switch";
$L["laser"] = "Laser";
$L["rand_card"] = "Zufällige Kreditkarte";
$L["ccrandom"] = "Wählen Karte Marke:";
$L["format_title"] = "Wenn die Länge der X nicht gleich der Kartenlänge so dass Format nicht erzeugt zu werden.";
$L["rand_brand_title"] = "Die ausgewählte Marke Kartenlänge und Format werden zufällig ausgewählt.";
$L["length"] = "Länge:";
$L["separators"] = "Abscheider:";
$L["ccformats"] = "Kreditkartenformate:";
