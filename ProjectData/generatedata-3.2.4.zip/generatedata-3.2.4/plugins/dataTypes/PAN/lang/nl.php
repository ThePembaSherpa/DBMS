<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PAN",
    "DESC" => "Dit soort gegevens genereert willekeurig, geldige credit card nummers volgens de indeling die u opgeeft."
);

$L["pan_incomplete_fields"] = "Tenminste een kaart merk worden gekozen. Please fix de volgende regels:";
$L["separator_help"] = "De tekens die u hier invoert, zal worden gebruikt om de ruimtes te vervangen in de Credit Card formaat veld hieronder. Om meer dan een separator te voeren, ze gewoon scheiden met een pijp (|) karakter.";
$L["format_incomplete_fields"] = "Voor PAN veld CC Getalnotaties, ingang <b>X</b> en voor afscheider ingang <b>ruimtes</b> volgens de kaart lengte. Please fix de volgende regels:";
$L["pan_help_intro"] = "Het is momenteel geschikt voor het genereren nummers voor de volgende merken: ";
$L["mastercard"] = "Mastercard";
$L["visa_electron"] = "Visa Electron";
$L["visa"] = "Visa";
$L["americanexpress"] = "American Express";
$L["discover"] = "Discover";
$L["american_diners"] = "American Diner's";
$L["carte_blanche"] = "Carte Blanche";
$L["diners_club_international"] = "Diner's Club International";
$L["enroute"] = "enRoute";
$L["jcb"] = "JCB";
$L["maestro"] = "Maestro";
$L["solo"] = "Solo";
$L["switch"] = "Switch";
$L["laser"] = "Laser";
$L["rand_card"] = "Random Credit Card";
$L["ccrandom"] = "Selecteer Card Merk:";
$L["format_title"] = "Indien de lengte van X niet gelijk is aan de kaart lengte dan dat formaat niet gegenereerd.";
$L["rand_brand_title"] = "De geselecteerde merk kaart lengte en het formaat zijn willekeurig gekozen.";
$L["length"] = "Lengte:";
$L["separators"] = "Scheiders:";
$L["ccformats"] = "Credit Card formaten:";
