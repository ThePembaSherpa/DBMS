## Region Data Type

This Data Type generates a random organisation number, used in some countries for registration of companies, associations etc...

### Example API Usage

Not available.

### API help

For more information about the API, check out:
[http://benkeen.github.io/generatedata/api.html](http://benkeen.github.io/generatedata/api.html)
