<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Genereert een willekeurig creditcard pincode van 1111 om 9999."
);
