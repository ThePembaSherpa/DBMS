<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Génère un code PIN aléatoire de carte de crédit de 1111 à 9999."
);
