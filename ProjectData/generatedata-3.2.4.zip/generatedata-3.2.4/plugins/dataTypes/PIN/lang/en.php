<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Generates a random credit card PIN number from 1111 to 9999."
);
