<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Straße",
    "DESC" => "Generiert zufällige Straßenadressen ."
);

$L["ap_num"] = "Ap #";
$L["name"] = "Straße";
$L["po_box"] = "Postfach";
$L["street_types"] = "St., St., Straße, Straße, Rd., Rd., Ave, Av., Avenue";
