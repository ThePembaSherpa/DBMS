<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Adresse",
    "DESC" => "Génère des adresses aléatoires ."
);

$L["ap_num"] = "Appartement ";
$L["name"] = "Adresse";
$L["po_box"] = "CP";
$L["street_types"] = "Rue,Route,Chemin,Rd.,Ave,Av.,Avenue,Impasse";
