<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Latitude / Longitude",
    "DESC" => "Dit gegevenstype genereert een willekeurig lengte-en / of lengte. Als beide zijn geselecteerd, geeft zowel een komma."
);

$L["latitude"] = "Speelruimte";
$L["longitude"] = "Lengte";
