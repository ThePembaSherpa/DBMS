<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Telefoon / Fax, Regionaal",
    "DESC" => "Dit Gegevenstype probeert een telefoonnummer in een geschikt formaat voor de rij met gegevens genereren. Komt hij een onbekend land, het genereert een standaard telefoonnummer in het formaat (xxx) xxx-xxxx."
);
