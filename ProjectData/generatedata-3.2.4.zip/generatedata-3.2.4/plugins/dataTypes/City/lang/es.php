<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Ciudad",
    "DESC" => "Muestra una ciudad al azar , o si se dispone de datos , muestra una ciudad para el país / región apropiada ."
);
