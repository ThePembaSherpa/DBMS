<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Normal Distribution",
    "DESC" => "Generates random normally distributed values with a customizable mean and standard deviation."
);

$L["mean"] = "Mean";
$L["standard_deviation"] = "Standard Deviation";
$L["incomplete_fields"] = "The Mean and Sigma fields are required for all Normal Distribution rows. Please fix the following rows:";
