<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Distribution Normale",
    "DESC" => "Génère des valeurs aléatoires normalement distribuées avec un écart moyen et l'écart personnalisable ."
);

$L["incomplete_fields"] = "Les champs 'Moyenne' et 'Ecart type' sont nécessaires pour toutes les lignes de distribution normale. Corrigez les lignes suivantes:";
$L["mean"] = "Moyenne";
$L["standard_deviation"] = "Écart type";
