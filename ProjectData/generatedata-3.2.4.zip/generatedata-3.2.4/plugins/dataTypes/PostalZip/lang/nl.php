<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Postal / Zip",
    "DESC" => "Genereert een willekeurig zip of postcode. Voor meer controle gebruikt u de alpha-numeriek gegevenstype optie."
);
