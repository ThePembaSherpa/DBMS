<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Postal / Zip",
    "DESC" => "Generates a random zip or postal code. For greater control, use the alpha-numeric data type option."
);
