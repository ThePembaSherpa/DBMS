<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Código postal",
    "DESC" => "Genera un código postal aleatorio. Para mayor control, utilice la opción de tipo de dato alfanumérico."
);
