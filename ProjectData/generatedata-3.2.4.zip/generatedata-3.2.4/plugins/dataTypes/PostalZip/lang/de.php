<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Postleitzahl / PLZ",
    "DESC" => "Generiert einen zufälligen Postleitzahl ein. Für eine bessere Kontrolle, verwenden Sie den alpha-numerischen Daten-Option aus."
);

