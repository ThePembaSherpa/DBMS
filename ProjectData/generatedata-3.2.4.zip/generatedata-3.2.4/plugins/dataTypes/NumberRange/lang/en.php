<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Number Range",
    "DESC" => "This randomly generates a number between the values you specify. Both fields allow you to enter negative numbers."
);

$L["and"] = "and";
$L["between"] = "Between";
$L["incomplete_fields"] = "Please enter the number range (lowest and highest numbers) for the following rows: ";
