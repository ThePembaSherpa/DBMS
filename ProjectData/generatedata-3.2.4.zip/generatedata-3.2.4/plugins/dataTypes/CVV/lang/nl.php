<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "CVV",
    "DESC" => "Genereert een willekeurig creditcard CVV nummer 111-999."
);
