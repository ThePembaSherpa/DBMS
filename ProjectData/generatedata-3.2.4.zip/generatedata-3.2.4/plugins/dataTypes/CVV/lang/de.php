<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "CVV",
    "DESC" => "Erzeugt eine Zufalls CVV-Nummer von 111 bis 999."
);
