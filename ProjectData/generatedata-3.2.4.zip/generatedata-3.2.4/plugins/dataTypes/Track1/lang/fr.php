<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 1",
    "DESC" => "Le morceau 1 contient le nom du titulaire de la carte ainsi que le numéro de compte et d'autres données discrétionnaires. La carte de crédit peut être de tout type (Visa, Mastercard, etc.)"
);
