<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 1",
    "DESC" => "Spur 1 enthält den Namen des Karteninhabers sowie die Kontonummer und andere Ermessens Daten. Die Kreditkarte kann von jedem Typ (Visa, Mastercard, etc.) sein."
);
