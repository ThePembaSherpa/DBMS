<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "E-mail",
    "DESC" => "Genereert een willekeurig e-mailadres."
);
