## Region Data Type

This Data Type generates a random personal number, used in some countries for social security insurance.

### Example API Usage

Not available.

### API help

For more information about the API, check out:
[http://benkeen.github.io/generatedata/api.html](http://benkeen.github.io/generatedata/api.html)
