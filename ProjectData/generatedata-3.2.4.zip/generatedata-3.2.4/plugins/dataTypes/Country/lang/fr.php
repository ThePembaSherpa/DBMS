<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Pays",
    "DESC" => "Génère un nom de pays aléatoire , avec la possibilité de limiter le sous-ensemble de ces pays sont entrés via l'interface ."
);

$L["limit_results"] = "Limiter les pays à ceux sélectionnés ci-dessus";
