<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "GUID",
    "DESC" => "Genera un GUID (identificador único global) al azar con el formato XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX, donde X es un dígito hexadecimal."
);

