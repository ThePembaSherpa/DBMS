<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "GUID",
    "DESC" => "Genereert een unieke, willekeurige GUID (globally unique identifier) ​​van de vorm: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX, waar X een hexadecimaal cijfer)."
);
