<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Random Number of Words",
    "DESC" => "This option generates a random number of words - the total number within the range that you specify (inclusive)."
);

$L["incomplete_fields"] = "Please enter the min and max number of words you want to generate for all Random Number of Words fields. See rows: ";
$L["start_with_lipsum"] = "Start with \"Lorem Ipsum...\"";
$L["generate"] = "Generate";
$L["to"] = "to";
$L["words"] = "words";
$L["help"] = "This option generates a random number of words - the total number within the range that you specify (inclusive). As with the Fixed number option, the words are pulled the standard lorem ipsum latin text.";
