<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Beliebige Anzahl von Wörtern",
    "DESC" => "Wie bei der Festnetznummer Option werden die Worte der Standard Lorem ipsum lateinischen Text gezogen."
);

$L["generate"] = "Erzeugen";
$L["help"] = "Wie bei der Festnetznummer Option werden die Worte der Standard Lorem ipsum lateinischen Text gezogen.";
$L["incomplete_fields"] = "Bitte geben Sie die min und max Anzahl der Wörter, die Sie für alle Random Number of Words Felder erzeugen. Siehe Zeilen:";
$L["start_with_lipsum"] = "Beginnen Sie mit \"Lorem ipsum...\"";
$L["to"] = "auf";
$L["words"] = "Text";
