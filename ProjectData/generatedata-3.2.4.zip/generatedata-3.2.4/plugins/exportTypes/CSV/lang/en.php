<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "CSV";

$L["delimiter_chars"] = "Delimiter char(s)";
$L["validation_no_delimiter"] = "Please enter a delimiter character for the CSV export type.";
$L["eol_char"] = "End of line character";
