<?php

$L = array();

$L["delimiter_chars"] = "Scheidingsteken char (s)";
$L["eol_char"] = "Einde van de lijn karakter";
$L["validation_no_delimiter"] = "Geef een scheidingsteken voor de CSV export type.";
