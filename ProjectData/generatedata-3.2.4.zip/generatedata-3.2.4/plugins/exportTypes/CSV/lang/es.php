<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "CSV";

$L["delimiter_chars"] = "Carácter(es) delimitador(es)";
$L["validation_no_delimiter"] = "Por favor, introduce un carácter delimitador para el tipo de exportación CSV.";
$L["eol_char"] = "Carácter de fin de línea";
