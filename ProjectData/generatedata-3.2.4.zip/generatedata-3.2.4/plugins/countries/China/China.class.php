<?php

/**
 * @package Countries
 */

/*
class Country_China extends CountryPlugin {
	protected $countryName = "China";
	protected $countrySlug = "china";
	protected $regionNames = "Chinese Regions";
	protected $continent = "asia";

//	protected $extendedData = array(
//		"zipFormat" => array(
//			"format" => "Xxxx",
//			"replacements" => array(
//				"X" => "123456789",
//				"x" => "0123456789"
//			)
//		),
//		"phoneFormat" => array(
//			"displayFormats" => array(
//				"Xxxx-xxxx",
//				"(0x) xxxx xxxx",
//				"04xx xxx xxx"
//			)
//		)
//	);

	protected $countryData = array(
		array(
			"regionName" => "East China",
			"regionShort" => "ACT",
			"regionSlug" => "east_china",
			"weight" => ,
			"cities" => array(
				"Canberra"
			)
		)
	);


	public function install() {
		return CountryPluginHelper::populateDB($this->countryName, $this->countrySlug, $this->countryData);
	}
}
*/